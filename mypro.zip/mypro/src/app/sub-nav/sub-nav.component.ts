import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sub-nav',
  templateUrl: './sub-nav.component.html',
  styleUrls: ['./sub-nav.component.css']
})
export class SubNavComponent implements OnInit {
  public SubNavList = [
    {"id": 1, "name": "Angular"},
    {"id": 2, "name": "vue"},
    {"id": 3, "name": "react"},
    {"id": 4, "name": "js"},
    {"id": 5, "name": "polimers"},
    {"id": 6, "name": "wijio"}
  ];

  constructor(private _router:Router) { }

  ngOnInit(): void {
  }
  onSelect(x){
this._router.navigate(['/SubNav', x.id]);
  }

}
