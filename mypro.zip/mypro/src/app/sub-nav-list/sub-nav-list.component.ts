import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-sub-nav-list',
  templateUrl: './sub-nav-list.component.html',
  styleUrls: ['./sub-nav-list.component.css']
})
export class SubNavListComponent implements OnInit {
public listId: any;
  constructor(private _activatedR: ActivatedRoute, private _router: Router) { }

  ngOnInit() {
    this._activatedR.paramMap.subscribe((params: ParamMap) => {
     //let id = parseInt(params.get('id')); 
    // this.listId = id;
      
    });
  }
  previous(){
    let prvId = this.listId - 1;
    this._router.navigate(['/SubNav',prvId]);
  }
  next(){
    let nxtId = this.listId + 1;
    this._router.navigate(['/SubNav',nxtId]);


  }

}
