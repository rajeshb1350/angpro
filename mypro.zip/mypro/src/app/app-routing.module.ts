import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAccessGuard } from './admin-access.guard';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { SubNavListComponent } from './sub-nav-list/sub-nav-list.component';
import { SubNavComponent } from './sub-nav/sub-nav.component';

const routes: Routes = [
  {path: '', redirectTo: '/MainNav', pathMatch:'full'},
{path: 'MainNav', component: MainNavComponent},
{path: 'AdminNav', component: AdminHomeComponent, canActivate: [AdminAccessGuard]},
{path: 'SubNav', component: SubNavComponent},
{path: 'SubNav/:id', component: SubNavListComponent},
{path: '**', component: PagenotfoundComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const myRouting = [MainNavComponent, SubNavComponent, SubNavListComponent ];
