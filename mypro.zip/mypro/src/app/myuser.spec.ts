import { Myuser } from './myuser';

describe('Myuser', () => {
  it('should create an instance', () => {
    expect(new Myuser()).toBeTruthy();
  });
});
