import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Myuser } from './myuser';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(_http: HttpClient) { }
}
