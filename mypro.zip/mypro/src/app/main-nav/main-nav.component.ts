import { Component, OnInit } from '@angular/core';
import {Myuser} from '../myuser'

@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.css']
})
export class MainNavComponent implements OnInit {


listedoption = ['Angular', 'react', 'vue', 'wijio'];
userModel = new Myuser('', '', '', '', 8500212402, '', '', true)
  constructor( ) { }

  ngOnInit(): void {
  }
  onFormSubmit(){
    console.log(this.userModel)
  }


}
