export class Myuser {
    constructor(
        public opt1: string,
        public opt2:string,
   public name: string,
   public   email: string,
   public    number: number,
   public gen: string,
   public course: string,
   public terms: boolean,
    ){}
    
}
