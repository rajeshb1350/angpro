import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentComponent } from './student/student.component';
import { TestComponent } from './test/test.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { myRouting } from './app-routing.module';
import { AdminAccessGuard } from './admin-access.guard';
import {FormsModule} from '@angular/forms'

@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    TestComponent,
    AdminHomeComponent,
    myRouting,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [AdminAccessGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
