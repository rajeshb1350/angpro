export interface Usermodel {
    username: string;
    email: string;

    number: number;
    gender: string;
    select: string;
    terms: boolean;
}
